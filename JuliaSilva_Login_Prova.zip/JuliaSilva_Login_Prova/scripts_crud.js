document.addEventListener("DOMContentLoaded", function () {
    // Seleciona o formulário de alteração pelo atributo action
    const form = document.querySelector('form[action="processa_alteracao_fornecedor.php"]');

    if (!form) return; // Se não existir, sai

    // Campos do formulário
    const nome = form.querySelector("#nome_fornecedor");
    const endereco = form.querySelector("#endereco");
    const telefone = form.querySelector("#telefone");
    const email = form.querySelector("#email");
    const contato = form.querySelector("#contato");

    // Bloqueia números no nome
    if (nome) {
        nome.addEventListener("keypress", function (e) {
            const char = String.fromCharCode(e.which);
            if (/\d/.test(char)) {
                e.preventDefault(); // Bloqueia número
            }
        });
    }

    // Máscara de telefone automática
    if (telefone) {
        telefone.addEventListener("input", function () {
            let valor = telefone.value.replace(/\D/g, "");
            if (valor.length > 11) valor = valor.slice(0, 11);

            if (valor.length >= 2) {
                valor = `(${valor.slice(0, 2)}) ${valor.slice(2)}`;
            }
            if (valor.length >= 10) {
                valor = valor.replace(/(\d{5})(\d{4})$/, "$1-$2");
            } else if (valor.length >= 9) {
                valor = valor.replace(/(\d{4})(\d{4})$/, "$1-$2");
            }

            telefone.value = valor;
        });
    }

    // Validação do formulário no submit
    form.addEventListener("submit", function (e) {
        const telefoneRegex = /^\(\d{2}\)\s?\d{4,5}-\d{4}$/;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const nomeRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ\s]+$/;

        let mensagens = [];

        if (!nome || nome.value.trim() === "") {
            mensagens.push("• Nome é obrigatório.");
        } else if (!nomeRegex.test(nome.value.trim())) {
            mensagens.push("• Nome deve conter apenas letras e espaços.");
        }

        if (!endereco || endereco.value.trim() === "") {
            mensagens.push("• Endereço é obrigatório.");
        }

        if (!telefone || !telefoneRegex.test(telefone.value.trim())) {
            mensagens.push("• Telefone inválido. Ex: (11) 91234-5678");
        }

        if (!email || !emailRegex.test(email.value.trim())) {
            mensagens.push("• Email inválido.");
        }

        if (!contato || contato.value.trim() === "") {
            mensagens.push("• Contato é obrigatório.");
        }

        if (mensagens.length > 0) {
            alert("Por favor, corrija os seguintes erros:\n\n" + mensagens.join("\n"));
            e.preventDefault();
        }
    });
});
